const { Router } = require('express');
const router = Router();
const publicController = require('../controllers/publicController');

router.get("/public/courseImage", publicController.viewCourseImg);

module.exports = router;