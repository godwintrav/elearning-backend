const Course = require('../models/Course');

module.exports.viewCourseImg = async (req, res) => {
    const id = req.params.id;
    const course = await Course.findById(id);
        console.log(course);
        var b64string = course.thumbnail.get('data');
        var buf = Buffer.from(b64string, 'base64');
        res.writeHead(200, { "Content-type": course.thumbnail.get('mimetype')});
        res.end(buf);
}