const Course = require("../models/Course");
const Lecture = require("../models/Lecture");
const User = require("../models/User");
const Category = require('../models/Category');
const Playlist = require("../models/Playlist");
const errorController = require('./errorController');
const { getVideoDurationInSeconds } = require('get-video-duration');

let Vimeo = require('vimeo').Vimeo;
let client = new Vimeo(process.env.CLIENT_ID, process.env.CLIENT_SECRET, process.env.PERSONAL_ACCESS_TOKEN);
//console.log(process.env.SECRET_CODE);
let uri;
let link;

module.exports.createCourse = async (req, res) => {
    const {userId, title, whatYouLearn, requirement, description, secondTitle, category} = req.body;
    try{
        const course = await Course.create({ user: userId, title, whatYouLearn, requirement, description, secondTitle, category, thumbnail: {
            data: req.file.buffer.toString('base64'),
            mimetype: req.file.mimetype
        }  });
        res.status(201).json({user: course.user, title: course.title, whatYouLearn: course.whatYouLearn, description: course.description, secondTitle: course.secondTitle, category: course.category});
    }catch(err){
        const errors = errorController.handleCourseErrors(err);
        res.status(404).json({ errors });
    }
}

module.exports.createPlaylist = async (req, res) => {
    const {courseId, name} = req.body;
    console.log(req.body)
    try{
        const playlist = await Playlist.create({ course: courseId, name: name });
        res.status(201).json(playlist);
    }catch(err){
        //console.log(err);
        const errors = errorController.handlePlaylistErrors(err);
        res.status(404).json({ errors });
    }
}

module.exports.createLecture = async (req, res) => {
    req.setTimeout(21600000);
    const {playlistId, title, description} = req.body;
    let link;
    let uri;
    let duration;
    try {
        const isValid = errorController.checkLectureErrors(req);
        console.log(req.file.path);
        getVideoDurationInSeconds(req.file.path).then((durationSec) => {
            duration = durationSec;
          });
        client.upload(
            req.file.path,
            {
                'name': req.body.title,
                'description': req.body.description,
                // 'privacy': {
                //     'view': 'disable'
                // },
                "upload": {
                    "size": req.file.size
                }
            },
            function(responseUri){
                console.log('Your video URI is ' + responseUri);
                uri = responseUri;
                console.log("The uri " + uri);
                client.request(responseUri + '?fields=link', function (error, body, statusCode, headers) {
                    if (error) {
                    console.log('There was an error making the request.')
                    console.log('Server reported: ' + error)
                    throw Error("error vimeo");
                    }
                    link = body.link;
                    console.log('Your video link is: ' + link);
                    saveLecture(playlistId, link, uri, description, title, res, duration);
                });
            },
            function(bytes_uploaded, bytes_total){
                var percentage = (bytes_uploaded / bytes_total * 100).toFixed(2);
                console.log(bytes_uploaded, bytes_total, percentage + "%");
            },
            function(error){
                console.log('Failed because: ' + error);
                throw Error("error vimeo");
            }
        );
    } catch(error){
        const errors = errorController.handleCreateLectureErrors(error); 
        res.status(404).json({ errors }); 
    }
}

const saveLecture = async (playlistId, link, uri, description, title, res, duration) => {
    try{
        const lecture = await Lecture.create({playlist: playlistId, title, description, link, uri, duration});
        const videos = await Lecture.find({playlist: playlistId});
        return res.status(201).json(videos);
    }catch(error){
        return res.status(500).json(error);
    }
}

module.exports.fetchInstructorCourses = async (req, res) => {
    const instructorId = req.params.id;
    try{
        const courses = await Course.find({ user: instructorId });
        if(courses){
            res.json(courses);
        }else{
            res.status(404).json({ errors: "Not Found" });
        }
    }catch(errors){
        res.status(404).json({ errors: errors.message });
    }
}

module.exports.viewCourse = async (req, res) => {
    const courseId = req.params.id;
    try{
        const course = await Course.findById(courseId);
        const instructor = await User.findById(course.user);
        var modules = [];
        var playlists = await Playlist.find({course: courseId}, '_id name');
        for (let index = 0; index < playlists.length; index++) {
            var module = {
                videos: []
            };
            module['sectionTitle'] = playlists[index].name;
            module['id'] = playlists[index]._id;
            const lectures = await fetchLectures(playlists[index]._id);
            module.videos = lectures;
            modules.push(module);
            console.log(module);
        }
        res.json({course: course, modules: modules, instructor: instructor });
    }catch(errors){
        res.status(404).json({ errors: errors.message });
    }
}

const fetchLectures = async (id) => {
    try{
        const lectures = await Lecture.find({playlist: id}, '_id title description link uri');
        return lectures;
    }catch(err){
        throw Error(err.message);
    }
}  

module.exports.viewLecture = async (req, res) => {
    const lectureId = req.params.id;
    try{
        const lecture = await Lecture.findById(lectureId);
        if(lecture){
            res.json(lecture);
        } else{
            res.status(404).json({ errors: "Not Found" });
        }  
    }catch(errors){
        res.status(404).json({ errors: "Not Found" });
    }
}

module.exports.fetchCategories = async (req, res) => {
    try{
        const categories = await Category.find().sort({ createdAt: -1 });
        res.json(categories);
    }catch(errors){
        res.status(404).json({ errors: errors.message });
    }
}

module.exports.deleteCourse = async (req, res) => {
    const { courseId } = req.body;

    try{
        const deletedCourse = await Course.findByIdAndDelete(courseId);
        res.json(deletedCourse);
    }catch(errors){
        res.status(404).json({ errors: errors.message });
    }
}

module.exports.deleteLecture = async (req, res) => {
    const { lectureId } = req.body;

    try{
        const deletedLecture = await Lecture.findByIdAndDelete(lectureId);
        res.json(deletedLecture);
    }catch(errors){
        res.status(404).json({ errors: errors.message });
    }
}
