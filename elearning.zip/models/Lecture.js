const mongoose = require('mongoose');
mongoose.set('useFindAndModify', false);

const lectureSchema = new mongoose.Schema({
    playlist: [{
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "playlist"
    }],
    link: {
        required: [true, "Please enter the category name"],
        type: String
    },
    title: {
        required: [true, "Please enter the category name"],
        type: String
    },
    description: {
        required: [true, "Please enter the category name"],
        type: String
    },
    uri: {
        required: [true, "Uri not sent"],
        type: String
    },
    duration: {
        type: mongoose.Decimal128,
        required: [true, "Please pass duration"]
    }  
}, { timestamps: true });


const Lecture = mongoose.model('lecture', lectureSchema);
module.exports = Lecture;